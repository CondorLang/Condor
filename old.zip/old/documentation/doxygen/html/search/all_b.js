var searchData=
[
  ['operator_20new',['operator new',['../class_cobra_1_1_isolate.html#a29b53dfacb699c647d8ae3db9cd799a9',1,'Cobra::Isolate::operator new()'],['../class_cobra_1_1_context.html#ac34fa8ed39938076d0441adabcbc1cd5',1,'Cobra::Context::operator new()']]]
];
