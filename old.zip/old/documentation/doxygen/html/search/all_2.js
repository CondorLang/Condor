var searchData=
[
  ['dispose',['Dispose',['../class_cobra_1_1_isolate.html#a82661d26d5141093293e28eb4d2c8417',1,'Cobra::Isolate']]]
];
