var searchData=
[
  ['version',['Version',['../namespace_cobra.html#a47f407730fdb699b15ddbca1e55826b6',1,'Cobra']]]
];
