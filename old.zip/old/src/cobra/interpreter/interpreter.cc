#include "interpreter.h"

namespace Cobra {
namespace internal{

	Interpreter::Interpreter(){}

} // namespace internal
} // namespace Cobra