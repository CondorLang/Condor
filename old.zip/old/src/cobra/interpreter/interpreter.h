#ifndef INTERPRETER_H_
#define INTERPRETER_H_

namespace Cobra {
namespace internal{

	class Interpreter
	{
	public:
		Interpreter();
		~Interpreter();
		
	};

} // namespace internal
} // namespace Cobra

#endif // INTERPRETER_H_