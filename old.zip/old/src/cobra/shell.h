#ifndef SHELL_H_
#define SHELL_H_

namespace Cobra {
namespace internal{

	#define UNDERLINE_START "\33[4m"
	#define UNDERLINE_STOP "\33[0m"

} // namespace internal
} // namespace Cobra

#endif // SHELL_H_