
namespace Cobra{
namespace internal{
        static const char* ArrayBytes = "236d6f64652022737472696374223b0a0a6578706f7274206f626a6563742041727261797b0a0966756e6320417272617928297b7d0a09696e74206c656e677468203d20303b0a7d";
} // namespace internal
} // namespace Cobra
    