CobraLang
=========

To do:
-------
  - Parser.cc -- Redo how Parsing Arrays occurs (Specifically the AST)
 		
Top Problems with Programming
-----------------------------
 - Code organization
 - Variable names (naming conventions)
 - Simplicity
 - Readability
 - (Java) Not too verbose
 - Memory Management